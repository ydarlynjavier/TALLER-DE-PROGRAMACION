
#include <stdio.h>

void verificar_par(int valor) {
    if (valor % 2 == 0) {
        printf("%d es par\n", valor);
    } else {
        printf("%d es impar\n", valor);
    }
return 0;
}
