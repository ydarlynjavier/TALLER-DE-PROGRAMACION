#include <stdio.h>
#include <math.h>
#include "tarea32.c"
#include "tarea33.c"

int main() {
    int num1, num2;
    printf("escribe el primer valor: ");
    scanf("%d", &num1);
    printf("escribe el segundo valor: ");
    scanf("%d", &num2);

}