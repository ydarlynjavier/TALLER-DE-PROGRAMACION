#include <math.h>

int sumar(int a, int b) { return a + b; }
int restar(int a, int b) { return a - b; }